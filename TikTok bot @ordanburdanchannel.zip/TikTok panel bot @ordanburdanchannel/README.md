Ad

# TPB (TİK TOK PANEL BOT)

# Qurulum

Video Tutorial : https://t.me/ordanburdanchannel/356 THIS* python <ShareBot.py Və ya ViewBot.py> * yapişdir video url * sayı seçin * proxy-ni silmək istəyirsinizsə, yes və ya no daxil edin * daxil etdiyiniz proxy növünü daxil edin Proxies.txt * proxy fasiləsini daxil edin | yaxşı bir fasilə istəyirsinizsə 3 seçin * mövzu daxil edin | daha çox ip = daha sürətli, lakin kompüterinizi yavaşlatın | seçin 100~1000

